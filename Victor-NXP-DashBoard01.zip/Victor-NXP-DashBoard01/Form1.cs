﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Victor_NXP_DashBoard01
{
    public partial class frmVictorNXP : Form
    {
        static SerialPort myserialPort;
        static bool isSerialConnected;
        static bool isThereAlreadyNewSerial;
        string rxString;

        //Console.Write("Test");

        public frmVictorNXP()
        {
            InitializeComponent();
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            comboBoxCommPorts.Items.Clear();
            foreach (string comm in SerialPort.GetPortNames())
            {
                comboBoxCommPorts.Items.Add(comm);
            }
        }

        private void comboBoxCommPorts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmVictorNXP_Load(object sender, EventArgs e)
        {
            Console.Write("Test");
            myserialPort = new SerialPort();
            myserialPort.DataReceived += new SerialDataReceivedEventHandler(myserialPort_DataReceived);

            SerialdataGridView.Columns[0].HeaderText = "Data Cnt";
            SerialdataGridView.Columns[1].HeaderText = "Data1";
            SerialdataGridView.Columns[2].HeaderText = "Data2";
            SerialdataGridView.Columns[3].HeaderText = "Data3";
            SerialdataGridView.Columns[4].HeaderText = "Data4";
            SerialdataGridView.Columns[5].HeaderText = "Data5";
        }

        private void btnCloseFrm_Click(object sender, EventArgs e)
        {
            if (myserialPort.IsOpen)
                myserialPort.Close();
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://victortagayun.github.io");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if(comboBoxCommPorts.Text == "")
            {
                MessageBox.Show("Please select correct Serial Comm port!", "ERROR");
            }
            else
            {
                if(btnConnect.Text == "Connect") // Connect
                {
                    if (myserialPort.IsOpen)
                    {
                        MessageBox.Show("Serial Comm port already open!", "ERROR");
                    }
                    else
                    {
                        myserialPort.PortName = comboBoxCommPorts.Text;
                        myserialPort.BaudRate = 19200;
                        myserialPort.Parity = Parity.None;
                        myserialPort.DataBits = 8;
                        myserialPort.StopBits = StopBits.One;
                        myserialPort.Handshake =0;

                        try // open port
                        {
                            myserialPort.Open();
                            txtSerialPort.Text = comboBoxCommPorts.Text;
                            btnConnect.Text = "Disconnect";
                            btnSend.Enabled = true;
                            txtSend.Enabled = true;
                        }
                        catch (Exception ex) // handle the exception
                        {
                            MessageBox.Show("Some app is using the PORT! Please Close the connection!", "ERROR");
                        }
                    }
                }
                else // Disconnect
                {
                    txtSerialPort.Text = "";
                    btnConnect.Text = "Connect";
                    myserialPort.Close();
                    btnSend.Enabled = false;
                    txtSend.Enabled = false;
                }

            }
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            if (myserialPort.IsOpen)
                myserialPort.Close();
            txtSerialPort.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myserialPort.WriteLine(txtSend.Text);
        }

        private void myserialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            rxString = myserialPort.ReadLine();
            this.Invoke(new EventHandler(DisplayText));
            //MessageBox.Show(data, "Received");
        }

        private void txtdebug_TextChanged(object sender, EventArgs e)
        {

        }

        private void DisplayText(object sender, EventArgs e)
        {
            rtbReceived.Text += rxString + "\n";

            string[] subs = rxString.Split(','); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

            foreach (var sub in subs)
            {                
                //Console.WriteLine($"Substring: {sub}");
                rtbSplit.Text += sub + "\n";
            }

            rtbSplit.Text = rtbSplit.Text + "Length = " + subs.Length + "\n";

            // string[] row = new string[] { "1", "Product 1", "1000" }; // http://csharp.net-informations.com/datagridview/csharp-datagridview-add-column.htm
            // dataGridView1.Rows.Add(row);

            SerialdataGridView.Rows.Add(subs);


        }

        private void SerialdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; col < SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells.Count; col++)
            {
               //string value = SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells[col].Value.ToString();
            }

            //richTextBox1.Text = richTextBox1.Text + "x" + "\n";

            MessageBox.Show("Pressed", "SerialdataGridView_CellContentClick");

        }

        private void SerialdataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MessageBox.Show("Pressed", "SerialdataGridView_CellMouseClick");
        }

        private void SerialdataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            // https://stackoverflow.com/questions/6487839/reading-data-from-datagridview-in-c-sharp

            //for (int col = 0; col < SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells.Count; col++)
            //{
            //   string value = SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells[col].Value.ToString();
            //}

            richTextBox1.Text = richTextBox1.Text + e.RowIndex + "\n";

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Random rdn = new Random();
            for (int i = 0; i < 500000; i++)
            {
                chart1.Series["Series1"].Points.AddXY(rdn.Next(0, 1000), rdn.Next(0, 1000));
                chart1.Series["Series2"].Points.AddXY(rdn.Next(0, 1000), rdn.Next(0, 1000));
            }

            //chart1.Series["test1"].ChartType = SeriesChartType.FastLine;
            chart1.Series["Series1"].Color = Color.Red;

            //chart1.Series["test2"].ChartType = SeriesChartType.FastLine;
            chart1.Series["Series2"].Color = Color.Blue;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Random rdn = new Random();
            myserialPort.WriteLine(rdn.Next(0,1000).ToString() + "," + rdn.Next(0, 1000).ToString() + "," + rdn.Next(0, 1000).ToString() + "," + rdn.Next(0, 1000).ToString() + "," + rdn.Next(0, 1000).ToString() + "," + rdn.Next(0, 1000).ToString());

        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtdebug.Text = SerialdataGridView.RowCount.ToString(); 
            //txtdebug.Text = SerialdataGridView.Rows.Count.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pressed", "button5_Click");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pressed", "button6_Click");
        }

        private void SerialdataGridView_RowValidated(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
