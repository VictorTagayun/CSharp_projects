Welcome to ScottPlot!

	⚠️ ScottPlot 4.1 was released in May, 2021 🚀
	* Users upgrading from 4.0 may be required to update their code to work with the 4.1 API
	* See https://swharden.com/scottplot/faq/version-4.1 for a summary of the major changes
	* ScottPlot 4.0 will always be available, but it is no longer actively maintained

	ScottPlot Quickstart - Create a plot with just a few lines of code
	* https://swharden.com/scottplot/quickstart

	ScottPlot Cookbook - Example plots next to the code used to create them
	* https://swharden.com/scottplot/cookbook

	ScottPlot FAQ - Common questions about styling, interactivity, and advanced use cases
	* https://swharden.com/scottplot/faq
		
	ScottPlot on GitHub - Bug reports, suggestions, and questions are welcome
	* https://github.com/ScottPlot/ScottPlot/issues
	* https://github.com/ScottPlot/ScottPlot/discussions

	If you enjoy ScottPlot, promote our project by giving us a star on GitHub! 🌟
	* https://github.com/ScottPlot/ScottPlot