﻿
namespace Victor_NXP_DashBoard01
{
    partial class frmVictorNXP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVictorNXP));
            this.btnScan = new System.Windows.Forms.Button();
            this.comboBoxCommPorts = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnCloseFrm = new System.Windows.Forms.Button();
            this.txtSerialPort = new System.Windows.Forms.TextBox();
            this.linkLabelgithub = new System.Windows.Forms.LinkLabel();
            this.txtdebug = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtSend = new System.Windows.Forms.TextBox();
            this.rtbReceived = new System.Windows.Forms.RichTextBox();
            this.timer_ms = new System.Windows.Forms.Timer(this.components);
            this.rtbSplit = new System.Windows.Forms.RichTextBox();
            this.SerialdataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblNXPDashBoard = new System.Windows.Forms.Label();
            this.chkEcho = new System.Windows.Forms.CheckBox();
            this.timer_timeout = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SerialdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnScan
            // 
            this.btnScan.Location = new System.Drawing.Point(1331, 14);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(71, 23);
            this.btnScan.TabIndex = 1;
            this.btnScan.Text = "Scan";
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // comboBoxCommPorts
            // 
            this.comboBoxCommPorts.FormattingEnabled = true;
            this.comboBoxCommPorts.Location = new System.Drawing.Point(1408, 16);
            this.comboBoxCommPorts.Name = "comboBoxCommPorts";
            this.comboBoxCommPorts.Size = new System.Drawing.Size(71, 21);
            this.comboBoxCommPorts.TabIndex = 2;
            this.comboBoxCommPorts.SelectedIndexChanged += new System.EventHandler(this.comboBoxCommPorts_SelectedIndexChanged);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(1331, 43);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(71, 23);
            this.btnConnect.TabIndex = 3;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnCloseFrm
            // 
            this.btnCloseFrm.Location = new System.Drawing.Point(1489, 14);
            this.btnCloseFrm.Name = "btnCloseFrm";
            this.btnCloseFrm.Size = new System.Drawing.Size(100, 23);
            this.btnCloseFrm.TabIndex = 4;
            this.btnCloseFrm.Text = "Quit Application";
            this.btnCloseFrm.UseVisualStyleBackColor = true;
            this.btnCloseFrm.Click += new System.EventHandler(this.btnCloseFrm_Click);
            // 
            // txtSerialPort
            // 
            this.txtSerialPort.Enabled = false;
            this.txtSerialPort.Location = new System.Drawing.Point(1408, 45);
            this.txtSerialPort.Name = "txtSerialPort";
            this.txtSerialPort.Size = new System.Drawing.Size(71, 20);
            this.txtSerialPort.TabIndex = 5;
            // 
            // linkLabelgithub
            // 
            this.linkLabelgithub.AutoSize = true;
            this.linkLabelgithub.Font = new System.Drawing.Font("Courier New", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelgithub.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabelgithub.LinkColor = System.Drawing.Color.LightSkyBlue;
            this.linkLabelgithub.Location = new System.Drawing.Point(12, 14);
            this.linkLabelgithub.Name = "linkLabelgithub";
            this.linkLabelgithub.Size = new System.Drawing.Size(429, 33);
            this.linkLabelgithub.TabIndex = 7;
            this.linkLabelgithub.TabStop = true;
            this.linkLabelgithub.Text = "victortagayun.github.io";
            this.linkLabelgithub.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // txtdebug
            // 
            this.txtdebug.Location = new System.Drawing.Point(538, 769);
            this.txtdebug.Multiline = true;
            this.txtdebug.Name = "txtdebug";
            this.txtdebug.Size = new System.Drawing.Size(148, 25);
            this.txtdebug.TabIndex = 8;
            this.txtdebug.TextChanged += new System.EventHandler(this.txtdebug_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkOrange;
            this.label1.Location = new System.Drawing.Point(14, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 27);
            this.label1.TabIndex = 9;
            this.label1.Text = "my first";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(139, 47);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(56, 57);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkOrange;
            this.label2.Location = new System.Drawing.Point(195, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 27);
            this.label2.TabIndex = 11;
            this.label2.Text = "app";
            // 
            // btnSend
            // 
            this.btnSend.Enabled = false;
            this.btnSend.Location = new System.Drawing.Point(116, 520);
            this.btnSend.Margin = new System.Windows.Forms.Padding(2);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(56, 19);
            this.btnSend.TabIndex = 12;
            this.btnSend.Text = "Send!";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtSend
            // 
            this.txtSend.Enabled = false;
            this.txtSend.Location = new System.Drawing.Point(11, 519);
            this.txtSend.Margin = new System.Windows.Forms.Padding(2);
            this.txtSend.Name = "txtSend";
            this.txtSend.Size = new System.Drawing.Size(101, 20);
            this.txtSend.TabIndex = 13;
            this.txtSend.TextChanged += new System.EventHandler(this.txtSend_TextChanged);
            this.txtSend.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSend_KeyDown);
            // 
            // rtbReceived
            // 
            this.rtbReceived.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbReceived.Location = new System.Drawing.Point(11, 108);
            this.rtbReceived.Margin = new System.Windows.Forms.Padding(2);
            this.rtbReceived.Name = "rtbReceived";
            this.rtbReceived.Size = new System.Drawing.Size(1578, 397);
            this.rtbReceived.TabIndex = 14;
            this.rtbReceived.Text = "";
            this.rtbReceived.TextChanged += new System.EventHandler(this.rtbReceived_TextChanged);
            // 
            // timer_ms
            // 
            this.timer_ms.Interval = 1;
            this.timer_ms.Tick += new System.EventHandler(this.timer_ms_Tick);
            // 
            // rtbSplit
            // 
            this.rtbSplit.Font = new System.Drawing.Font("Courier New", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbSplit.Location = new System.Drawing.Point(11, 552);
            this.rtbSplit.Margin = new System.Windows.Forms.Padding(2);
            this.rtbSplit.Name = "rtbSplit";
            this.rtbSplit.Size = new System.Drawing.Size(1578, 77);
            this.rtbSplit.TabIndex = 17;
            this.rtbSplit.Text = "";
            this.rtbSplit.TextChanged += new System.EventHandler(this.rtbSplit_TextChanged);
            // 
            // SerialdataGridView
            // 
            this.SerialdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SerialdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.SerialdataGridView.Location = new System.Drawing.Point(11, 643);
            this.SerialdataGridView.Name = "SerialdataGridView";
            this.SerialdataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SerialdataGridView.Size = new System.Drawing.Size(1577, 79);
            this.SerialdataGridView.TabIndex = 18;
            this.SerialdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SerialdataGridView_CellContentClick);
            this.SerialdataGridView.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.SerialdataGridView_RowsAdded);
            this.SerialdataGridView.RowValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.SerialdataGridView_RowValidated);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Column3";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Column4";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Column5";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Column6";
            this.Column6.Name = "Column6";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(790, 767);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "packet";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(801, 815);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "TImer On";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(936, 815);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "Timer oFF";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(709, 767);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 23;
            this.button4.Text = "GridView Size";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Font = new System.Drawing.Font("Courier New", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox1.Location = new System.Drawing.Point(216, 748);
            this.richTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(187, 58);
            this.richTextBox1.TabIndex = 24;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // lblNXPDashBoard
            // 
            this.lblNXPDashBoard.AutoSize = true;
            this.lblNXPDashBoard.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNXPDashBoard.ForeColor = System.Drawing.Color.Gold;
            this.lblNXPDashBoard.Location = new System.Drawing.Point(528, 23);
            this.lblNXPDashBoard.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNXPDashBoard.Name = "lblNXPDashBoard";
            this.lblNXPDashBoard.Size = new System.Drawing.Size(555, 56);
            this.lblNXPDashBoard.TabIndex = 25;
            this.lblNXPDashBoard.Text = "NXP DC-DC Dashboard";
            // 
            // chkEcho
            // 
            this.chkEcho.AutoSize = true;
            this.chkEcho.Checked = true;
            this.chkEcho.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEcho.Location = new System.Drawing.Point(186, 522);
            this.chkEcho.Name = "chkEcho";
            this.chkEcho.Size = new System.Drawing.Size(80, 17);
            this.chkEcho.TabIndex = 26;
            this.chkEcho.Text = "Local Echo";
            this.chkEcho.UseVisualStyleBackColor = true;
            // 
            // timer_timeout
            // 
            this.timer_timeout.Tick += new System.EventHandler(this.timer_timeout_Tick);
            // 
            // frmVictorNXP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1600, 860);
            this.ControlBox = false;
            this.Controls.Add(this.chkEcho);
            this.Controls.Add(this.lblNXPDashBoard);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SerialdataGridView);
            this.Controls.Add(this.rtbSplit);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.rtbReceived);
            this.Controls.Add(this.txtSend);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtdebug);
            this.Controls.Add(this.linkLabelgithub);
            this.Controls.Add(this.txtSerialPort);
            this.Controls.Add(this.btnCloseFrm);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.comboBoxCommPorts);
            this.Controls.Add(this.btnScan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmVictorNXP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "victortagayun.github.io by Victor Tagayun";
            this.Load += new System.EventHandler(this.frmVictorNXP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SerialdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.ComboBox comboBoxCommPorts;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnCloseFrm;
        private System.Windows.Forms.TextBox txtSerialPort;
        private System.Windows.Forms.LinkLabel linkLabelgithub;
        private System.Windows.Forms.TextBox txtdebug;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtSend;
        private System.Windows.Forms.RichTextBox rtbReceived;
        private System.Windows.Forms.Timer timer_ms;
        private System.Windows.Forms.RichTextBox rtbSplit;
        private System.Windows.Forms.DataGridView SerialdataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblNXPDashBoard;
        private System.Windows.Forms.CheckBox chkEcho;
        private System.Windows.Forms.Timer timer_timeout;
    }
}

