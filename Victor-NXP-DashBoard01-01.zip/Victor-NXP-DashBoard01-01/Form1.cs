﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Victor_NXP_DashBoard01
{
    public partial class frmVictorNXP : Form
    {
        static SerialPort myserialPort;
        static bool isSerialConnected;
        static bool isThereAlreadyNewSerial;
        string rxString;
        string[] SerialPacket = new string[100];
        int SerialPacketCntr = 0;
        uint mS_cntr, mS_cntr_timeout;
        bool isMsgEnabled;
        bool isDatalogOn;
        bool isJustOpened = true;
        string CmdSent;

        //Console.Write("Test");

        public frmVictorNXP()
        {
            InitializeComponent();
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            comboBoxCommPorts.Items.Clear();
            foreach (string comm in SerialPort.GetPortNames())
            {
                comboBoxCommPorts.Items.Add(comm);
            }
        }

        private void comboBoxCommPorts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmVictorNXP_Load(object sender, EventArgs e)
        {
            Console.Write("Test");
            myserialPort = new SerialPort();
            myserialPort.DataReceived += new SerialDataReceivedEventHandler(myserialPort_DataReceived);

            SerialdataGridView.Columns[0].HeaderText = "Data Cnt";
            SerialdataGridView.Columns[1].HeaderText = "Data1";
            SerialdataGridView.Columns[2].HeaderText = "Data2";
            SerialdataGridView.Columns[3].HeaderText = "Data3";
            SerialdataGridView.Columns[4].HeaderText = "Data4";
            SerialdataGridView.Columns[5].HeaderText = "Data5";
        }

        private void btnCloseFrm_Click(object sender, EventArgs e)
        {
            if (myserialPort.IsOpen)
                myserialPort.Close();
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://victortagayun.github.io");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if(comboBoxCommPorts.Text == "")
            {
                MessageBox.Show("Please select correct Serial Comm port!", "ERROR");
            }
            else
            {
                if(btnConnect.Text == "Connect") // Connect
                {
                    if (myserialPort.IsOpen) // Connect : error on connection
                    {
                        MessageBox.Show("Serial Comm port already open!", "ERROR");
                    }
                    else
                    {
                        myserialPort.PortName = comboBoxCommPorts.Text;
                        myserialPort.BaudRate = 19200;
                        myserialPort.Parity = Parity.None;
                        myserialPort.DataBits = 8;
                        myserialPort.StopBits = StopBits.One;
                        myserialPort.Handshake =0;

                        try // open port
                        {
                            myserialPort.Open();
                            txtSerialPort.Text = comboBoxCommPorts.Text;
                            btnConnect.Text = "Disconnect";
                            btnSend.Enabled = true;
                            txtSend.Enabled = true;

                            mS_cntr_timeout = 1000;
                        }
                        catch (Exception ex) // handle the exception
                        {
                            MessageBox.Show("Some app is using the PORT! Please Close the connection!", "ERROR");
                        }
                    }
                }
                else // Disconnect
                {
                    txtSerialPort.Text = "";
                    btnConnect.Text = "Connect";
                    myserialPort.Close();
                    btnSend.Enabled = false;
                    txtSend.Enabled = false;
                }

            }
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            if (myserialPort.IsOpen)
                myserialPort.Close();
            txtSerialPort.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myserialPort.WriteLine(txtSend.Text);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (chkEcho.Checked)
            {
                rtbReceived.Text += txtSend.Text + "\n";
            }
            myserialPort.WriteLine(txtSend.Text);
        }

        private void myserialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            rxString = myserialPort.ReadLine();
            this.Invoke(new EventHandler(DisplayText));
            //MessageBox.Show(data, "Received");
            //SerialPacket[SerialPacketCntr++] += rxString;
        }

        private void txtdebug_TextChanged(object sender, EventArgs e)
        {

        }

        private void DisplayText(object sender, EventArgs e)
        {
            rtbReceived.Text += rxString + "\n";

            SerialPacketCntr++;

            string[] subs = rxString.Split(',',' ','='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

            foreach (var sub in subs)
            {
                //Console.WriteLine($"Substring: {sub}");
                rtbSplit.Text += sub + "*"; // + "\n";
            }

            rtbSplit.Text = rtbSplit.Text + ">>>>> Length = " + subs.Length + ", mS_cntr = " + mS_cntr.ToString() + ", SerialPacketCntr = " + SerialPacketCntr.ToString() + "\n";

            // string[] row = new string[] { "1", "Product 1", "1000" }; // http://csharp.net-informations.com/datagridview/csharp-datagridview-add-column.htm
            // dataGridView1.Rows.Add(row);

            //SerialdataGridView.Rows.Add(subs);

            //richTextBox1.Text += mS_cntr.ToString() + "\n";

            mS_cntr = 0;

        }

        private void SerialdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; col < SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells.Count; col++)
            {
               //string value = SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells[col].Value.ToString();
            }

            //richTextBox1.Text = richTextBox1.Text + "x" + "\n";

            MessageBox.Show("Pressed", "SerialdataGridView_CellContentClick");

        }

        private void SerialdataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MessageBox.Show("Pressed", "SerialdataGridView_CellMouseClick");
        }

        private void SerialdataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            // https://stackoverflow.com/questions/6487839/reading-data-from-datagridview-in-c-sharp

            //for (int col = 0; col < SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells.Count; col++)
            //{
            //   string value = SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells[col].Value.ToString();
            //}

            //richTextBox1.Text = richTextBox1.Text + e.RowIndex + "\n";

        }


        private void timer_ms_Tick(object sender, EventArgs e)
        {
            mS_cntr++;
            txtdebug.Text = mS_cntr.ToString();
            //if (mS_cntr > mS_cntr_timeout)
            //{
            //    timer_ms.Enabled = false;
            //}
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer_ms.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer_ms.Enabled = false;
            mS_cntr = 0;
            SerialPacketCntr = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtdebug.Text = SerialdataGridView.RowCount.ToString() + ", " + SerialdataGridView.Rows[1].Cells.Count.ToString(); 

            //txtdebug.Text = SerialdataGridView.Rows.Count.ToString();
        }

        private void SerialdataGridView_RowValidated(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSend_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (chkEcho.Checked)
                {
                    rtbReceived.Text += txtSend.Text + "\n";
                }
                timer_ms.Enabled = true;
                myserialPort.WriteLine(txtSend.Text);
            }
        }

        private void rtbReceived_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            rtbReceived.SelectionStart = rtbReceived.Text.Length;
            // scroll it automatically
            rtbReceived.ScrollToCaret();
        }

        private void rtbSplit_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            rtbSplit.SelectionStart = rtbSplit.Text.Length;
            // scroll it automatically
            rtbSplit.ScrollToCaret();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            txtdebug.Text = SerialPacketCntr.ToString();
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            txtdebug.Text = SerialPacketCntr.ToString();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            // scroll it automatically
            richTextBox1.ScrollToCaret();
        }

        private void txtSend_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer_timeout_Tick(object sender, EventArgs e)
        {

        }
    }
}

/*
 * When start of connect to UART 2 conditions:
 * 1. w Dlog, set ismsgenbled = true
 * 2. no Dlog, set ismsgenbled = false
 * 
 * note: set timeout until enable the send command button
 * 
 */