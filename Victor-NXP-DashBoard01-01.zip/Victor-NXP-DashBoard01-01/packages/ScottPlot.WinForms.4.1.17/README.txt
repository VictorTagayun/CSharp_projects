This pre-release version of ScottPlot is functional, but its API may change in future packages.
 
	ScottPlot Cookbook:
	https://swharden.com/scottplot/cookbook
	
	Changes are described on the releases page:
	https://github.com/swharden/ScottPlot/releases

	Bug reports are welcome:
	https://github.com/swharden/ScottPlot/issues