﻿
namespace Victor_NXP_DashBoard01
{
    partial class frmVictorNXP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVictorNXP));
            this.btnScan = new System.Windows.Forms.Button();
            this.comboBoxCommPorts = new System.Windows.Forms.ComboBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.btnCloseFrm = new System.Windows.Forms.Button();
            this.txtSerialPort = new System.Windows.Forms.TextBox();
            this.linkLabelgithub = new System.Windows.Forms.LinkLabel();
            this.txtdebug = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSend = new System.Windows.Forms.Button();
            this.txtSend = new System.Windows.Forms.TextBox();
            this.rtbReceived = new System.Windows.Forms.RichTextBox();
            this.timer_ms = new System.Windows.Forms.Timer(this.components);
            this.rtbSplit = new System.Windows.Forms.RichTextBox();
            this.SerialdataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.rtbDebug = new System.Windows.Forms.RichTextBox();
            this.lblNXPDashBoard = new System.Windows.Forms.Label();
            this.chkEcho = new System.Windows.Forms.CheckBox();
            this.timer_timeout = new System.Windows.Forms.Timer(this.components);
            this.txtFWDate = new System.Windows.Forms.TextBox();
            this.txtVoutSet = new System.Windows.Forms.TextBox();
            this.txtVinB4Fuse = new System.Windows.Forms.TextBox();
            this.txtVin = new System.Windows.Forms.TextBox();
            this.txtVout = new System.Windows.Forms.TextBox();
            this.txtVorFET = new System.Windows.Forms.TextBox();
            this.txtIin = new System.Windows.Forms.TextBox();
            this.txtIout = new System.Windows.Forms.TextBox();
            this.txtAirIn = new System.Windows.Forms.TextBox();
            this.txtAirOut = new System.Windows.Forms.TextBox();
            this.txtPOI1 = new System.Windows.Forms.TextBox();
            this.txtPOI2 = new System.Windows.Forms.TextBox();
            this.txtPOI3 = new System.Windows.Forms.TextBox();
            this.txtPOI4 = new System.Windows.Forms.TextBox();
            this.txtVinGain = new System.Windows.Forms.TextBox();
            this.txtVoutGain = new System.Windows.Forms.TextBox();
            this.txtIinGain = new System.Windows.Forms.TextBox();
            this.txtIoutGain = new System.Windows.Forms.TextBox();
            this.txtIoutOffset = new System.Windows.Forms.TextBox();
            this.txtIinOffset = new System.Windows.Forms.TextBox();
            this.txtVoutOffset = new System.Windows.Forms.TextBox();
            this.txtVinOffset = new System.Windows.Forms.TextBox();
            this.txtDroopBound = new System.Windows.Forms.TextBox();
            this.txtDroopConst = new System.Windows.Forms.TextBox();
            this.txtCANid = new System.Windows.Forms.TextBox();
            this.txtLoadSharing = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.txtLoadSharingDutyAve = new System.Windows.Forms.TextBox();
            this.txtLoadSharingPeerAve = new System.Windows.Forms.TextBox();
            this.txtSelfIoutCheat = new System.Windows.Forms.TextBox();
            this.txtDebugTime = new System.Windows.Forms.TextBox();
            this.txtDebugFreq = new System.Windows.Forms.TextBox();
            this.txtDebugCntr = new System.Windows.Forms.TextBox();
            this.txtDebugPts = new System.Windows.Forms.TextBox();
            this.txtOpenLoopDuty = new System.Windows.Forms.TextBox();
            this.txtContrlLoop = new System.Windows.Forms.TextBox();
            this.txtKi = new System.Windows.Forms.TextBox();
            this.txtKp = new System.Windows.Forms.TextBox();
            this.txtFWTime = new System.Windows.Forms.TextBox();
            this.txtSOAVinMin = new System.Windows.Forms.TextBox();
            this.txtSOAVinMax = new System.Windows.Forms.TextBox();
            this.txtFanDetection = new System.Windows.Forms.TextBox();
            this.txtFanSpeed = new System.Windows.Forms.TextBox();
            this.txtSOAIavg2 = new System.Windows.Forms.TextBox();
            this.txtSOAIavg1 = new System.Windows.Forms.TextBox();
            this.txtSOAIoutMax = new System.Windows.Forms.TextBox();
            this.txtSOAVoutMax = new System.Windows.Forms.TextBox();
            this.txtSOAIrms3 = new System.Windows.Forms.TextBox();
            this.txtSOAIrms2 = new System.Windows.Forms.TextBox();
            this.txtSOAIrms1 = new System.Windows.Forms.TextBox();
            this.txtSOAIavg3 = new System.Windows.Forms.TextBox();
            this.txtSOAtemp3 = new System.Windows.Forms.TextBox();
            this.txtSOAtemp2 = new System.Windows.Forms.TextBox();
            this.txtSOAtemp1 = new System.Windows.Forms.TextBox();
            this.txtSOAIrms4 = new System.Windows.Forms.TextBox();
            this.txtHWFOTPstat = new System.Windows.Forms.TextBox();
            this.txtHWFOVPstat = new System.Windows.Forms.TextBox();
            this.txtHWFOCPstat = new System.Windows.Forms.TextBox();
            this.txtSOAtemp4 = new System.Windows.Forms.TextBox();
            this.txtHWFOVPenabled = new System.Windows.Forms.TextBox();
            this.txtHWFOCPenabled = new System.Windows.Forms.TextBox();
            this.txtHWFDCFstat = new System.Windows.Forms.TextBox();
            this.txtHWFMFSstat = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.txtHWFDCFenabled = new System.Windows.Forms.TextBox();
            this.txtHWFMFSenabled = new System.Windows.Forms.TextBox();
            this.txtHWFOTPenabled = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.txtEff = new System.Windows.Forms.TextBox();
            this.txtPin = new System.Windows.Forms.TextBox();
            this.txtPout = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SerialdataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnScan
            // 
            this.btnScan.Location = new System.Drawing.Point(1331, 14);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(71, 23);
            this.btnScan.TabIndex = 1;
            this.btnScan.Text = "Scan";
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.btnScan_Click);
            // 
            // comboBoxCommPorts
            // 
            this.comboBoxCommPorts.FormattingEnabled = true;
            this.comboBoxCommPorts.Location = new System.Drawing.Point(1408, 16);
            this.comboBoxCommPorts.Name = "comboBoxCommPorts";
            this.comboBoxCommPorts.Size = new System.Drawing.Size(71, 21);
            this.comboBoxCommPorts.TabIndex = 2;
            this.comboBoxCommPorts.SelectedIndexChanged += new System.EventHandler(this.comboBoxCommPorts_SelectedIndexChanged);
            // 
            // btnConnect
            // 
            this.btnConnect.Location = new System.Drawing.Point(1331, 43);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(71, 23);
            this.btnConnect.TabIndex = 3;
            this.btnConnect.Text = "Connect";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click);
            // 
            // btnCloseFrm
            // 
            this.btnCloseFrm.Location = new System.Drawing.Point(1489, 14);
            this.btnCloseFrm.Name = "btnCloseFrm";
            this.btnCloseFrm.Size = new System.Drawing.Size(100, 23);
            this.btnCloseFrm.TabIndex = 4;
            this.btnCloseFrm.Text = "Quit Application";
            this.btnCloseFrm.UseVisualStyleBackColor = true;
            this.btnCloseFrm.Click += new System.EventHandler(this.btnCloseFrm_Click);
            // 
            // txtSerialPort
            // 
            this.txtSerialPort.Enabled = false;
            this.txtSerialPort.Location = new System.Drawing.Point(1408, 45);
            this.txtSerialPort.Name = "txtSerialPort";
            this.txtSerialPort.Size = new System.Drawing.Size(71, 20);
            this.txtSerialPort.TabIndex = 5;
            // 
            // linkLabelgithub
            // 
            this.linkLabelgithub.AutoSize = true;
            this.linkLabelgithub.Font = new System.Drawing.Font("Courier New", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabelgithub.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabelgithub.LinkColor = System.Drawing.Color.LightSkyBlue;
            this.linkLabelgithub.Location = new System.Drawing.Point(12, 14);
            this.linkLabelgithub.Name = "linkLabelgithub";
            this.linkLabelgithub.Size = new System.Drawing.Size(429, 33);
            this.linkLabelgithub.TabIndex = 7;
            this.linkLabelgithub.TabStop = true;
            this.linkLabelgithub.Text = "victortagayun.github.io";
            this.linkLabelgithub.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // txtdebug
            // 
            this.txtdebug.Location = new System.Drawing.Point(128, 813);
            this.txtdebug.Multiline = true;
            this.txtdebug.Name = "txtdebug";
            this.txtdebug.Size = new System.Drawing.Size(148, 25);
            this.txtdebug.TabIndex = 8;
            this.txtdebug.TextChanged += new System.EventHandler(this.txtdebug_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkOrange;
            this.label1.Location = new System.Drawing.Point(14, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 27);
            this.label1.TabIndex = 9;
            this.label1.Text = "my first";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(139, 47);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(56, 57);
            this.pictureBox1.TabIndex = 10;
            this.pictureBox1.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkOrange;
            this.label2.Location = new System.Drawing.Point(195, 63);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 27);
            this.label2.TabIndex = 11;
            this.label2.Text = "app";
            // 
            // btnSend
            // 
            this.btnSend.Enabled = false;
            this.btnSend.Location = new System.Drawing.Point(116, 476);
            this.btnSend.Margin = new System.Windows.Forms.Padding(2);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(56, 19);
            this.btnSend.TabIndex = 12;
            this.btnSend.Text = "Send!";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtSend
            // 
            this.txtSend.Enabled = false;
            this.txtSend.Location = new System.Drawing.Point(11, 475);
            this.txtSend.Margin = new System.Windows.Forms.Padding(2);
            this.txtSend.Name = "txtSend";
            this.txtSend.Size = new System.Drawing.Size(101, 20);
            this.txtSend.TabIndex = 13;
            this.txtSend.TextChanged += new System.EventHandler(this.txtSend_TextChanged);
            this.txtSend.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSend_KeyDown);
            // 
            // rtbReceived
            // 
            this.rtbReceived.Font = new System.Drawing.Font("Courier New", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbReceived.Location = new System.Drawing.Point(11, 108);
            this.rtbReceived.Margin = new System.Windows.Forms.Padding(2);
            this.rtbReceived.Name = "rtbReceived";
            this.rtbReceived.Size = new System.Drawing.Size(1578, 346);
            this.rtbReceived.TabIndex = 14;
            this.rtbReceived.Text = "";
            this.rtbReceived.TextChanged += new System.EventHandler(this.rtbReceived_TextChanged);
            // 
            // timer_ms
            // 
            this.timer_ms.Interval = 1;
            this.timer_ms.Tick += new System.EventHandler(this.timer_ms_Tick);
            // 
            // rtbSplit
            // 
            this.rtbSplit.Font = new System.Drawing.Font("Courier New", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbSplit.Location = new System.Drawing.Point(11, 516);
            this.rtbSplit.Margin = new System.Windows.Forms.Padding(2);
            this.rtbSplit.Name = "rtbSplit";
            this.rtbSplit.Size = new System.Drawing.Size(1578, 113);
            this.rtbSplit.TabIndex = 17;
            this.rtbSplit.Text = "";
            this.rtbSplit.TextChanged += new System.EventHandler(this.rtbSplit_TextChanged);
            // 
            // SerialdataGridView
            // 
            this.SerialdataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SerialdataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6});
            this.SerialdataGridView.Location = new System.Drawing.Point(11, 643);
            this.SerialdataGridView.Name = "SerialdataGridView";
            this.SerialdataGridView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.SerialdataGridView.Size = new System.Drawing.Size(1577, 79);
            this.SerialdataGridView.TabIndex = 18;
            this.SerialdataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SerialdataGridView_CellContentClick);
            this.SerialdataGridView.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.SerialdataGridView_RowsAdded);
            this.SerialdataGridView.RowValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.SerialdataGridView_RowValidated);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Column3";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Column4";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Column5";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Column6";
            this.Column6.Name = "Column6";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(209, 732);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 20;
            this.button1.Text = "packet";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_3);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(128, 732);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 21;
            this.button2.Text = "TImer On";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(128, 761);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "Timer oFF";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(209, 765);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 23;
            this.button4.Text = "GridView Size";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // rtbDebug
            // 
            this.rtbDebug.Font = new System.Drawing.Font("Courier New", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDebug.Location = new System.Drawing.Point(8, 736);
            this.rtbDebug.Margin = new System.Windows.Forms.Padding(2);
            this.rtbDebug.Name = "rtbDebug";
            this.rtbDebug.Size = new System.Drawing.Size(104, 102);
            this.rtbDebug.TabIndex = 24;
            this.rtbDebug.Text = "";
            this.rtbDebug.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // lblNXPDashBoard
            // 
            this.lblNXPDashBoard.AutoSize = true;
            this.lblNXPDashBoard.Font = new System.Drawing.Font("Arial", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNXPDashBoard.ForeColor = System.Drawing.Color.Gold;
            this.lblNXPDashBoard.Location = new System.Drawing.Point(528, 23);
            this.lblNXPDashBoard.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNXPDashBoard.Name = "lblNXPDashBoard";
            this.lblNXPDashBoard.Size = new System.Drawing.Size(733, 56);
            this.lblNXPDashBoard.TabIndex = 25;
            this.lblNXPDashBoard.Text = "VictorT NXP DC-DC Dashboard";
            // 
            // chkEcho
            // 
            this.chkEcho.AutoSize = true;
            this.chkEcho.Checked = true;
            this.chkEcho.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEcho.Location = new System.Drawing.Point(186, 478);
            this.chkEcho.Name = "chkEcho";
            this.chkEcho.Size = new System.Drawing.Size(80, 17);
            this.chkEcho.TabIndex = 26;
            this.chkEcho.Text = "Local Echo";
            this.chkEcho.UseVisualStyleBackColor = true;
            // 
            // timer_timeout
            // 
            this.timer_timeout.Tick += new System.EventHandler(this.timer_timeout_Tick);
            // 
            // txtFWDate
            // 
            this.txtFWDate.Location = new System.Drawing.Point(306, 728);
            this.txtFWDate.Multiline = true;
            this.txtFWDate.Name = "txtFWDate";
            this.txtFWDate.Size = new System.Drawing.Size(80, 25);
            this.txtFWDate.TabIndex = 27;
            // 
            // txtVoutSet
            // 
            this.txtVoutSet.Location = new System.Drawing.Point(389, 726);
            this.txtVoutSet.Multiline = true;
            this.txtVoutSet.Name = "txtVoutSet";
            this.txtVoutSet.Size = new System.Drawing.Size(60, 25);
            this.txtVoutSet.TabIndex = 28;
            // 
            // txtVinB4Fuse
            // 
            this.txtVinB4Fuse.Location = new System.Drawing.Point(389, 757);
            this.txtVinB4Fuse.Multiline = true;
            this.txtVinB4Fuse.Name = "txtVinB4Fuse";
            this.txtVinB4Fuse.Size = new System.Drawing.Size(60, 25);
            this.txtVinB4Fuse.TabIndex = 29;
            // 
            // txtVin
            // 
            this.txtVin.Location = new System.Drawing.Point(389, 788);
            this.txtVin.Multiline = true;
            this.txtVin.Name = "txtVin";
            this.txtVin.Size = new System.Drawing.Size(60, 25);
            this.txtVin.TabIndex = 30;
            // 
            // txtVout
            // 
            this.txtVout.Location = new System.Drawing.Point(456, 730);
            this.txtVout.Multiline = true;
            this.txtVout.Name = "txtVout";
            this.txtVout.Size = new System.Drawing.Size(60, 25);
            this.txtVout.TabIndex = 31;
            // 
            // txtVorFET
            // 
            this.txtVorFET.Location = new System.Drawing.Point(456, 761);
            this.txtVorFET.Multiline = true;
            this.txtVorFET.Name = "txtVorFET";
            this.txtVorFET.Size = new System.Drawing.Size(60, 25);
            this.txtVorFET.TabIndex = 32;
            // 
            // txtIin
            // 
            this.txtIin.Location = new System.Drawing.Point(456, 792);
            this.txtIin.Multiline = true;
            this.txtIin.Name = "txtIin";
            this.txtIin.Size = new System.Drawing.Size(60, 25);
            this.txtIin.TabIndex = 33;
            // 
            // txtIout
            // 
            this.txtIout.Location = new System.Drawing.Point(456, 823);
            this.txtIout.Multiline = true;
            this.txtIout.Name = "txtIout";
            this.txtIout.Size = new System.Drawing.Size(60, 25);
            this.txtIout.TabIndex = 34;
            // 
            // txtAirIn
            // 
            this.txtAirIn.Location = new System.Drawing.Point(522, 732);
            this.txtAirIn.Multiline = true;
            this.txtAirIn.Name = "txtAirIn";
            this.txtAirIn.Size = new System.Drawing.Size(60, 25);
            this.txtAirIn.TabIndex = 35;
            // 
            // txtAirOut
            // 
            this.txtAirOut.Location = new System.Drawing.Point(522, 765);
            this.txtAirOut.Multiline = true;
            this.txtAirOut.Name = "txtAirOut";
            this.txtAirOut.Size = new System.Drawing.Size(60, 25);
            this.txtAirOut.TabIndex = 36;
            // 
            // txtPOI1
            // 
            this.txtPOI1.Location = new System.Drawing.Point(522, 796);
            this.txtPOI1.Multiline = true;
            this.txtPOI1.Name = "txtPOI1";
            this.txtPOI1.Size = new System.Drawing.Size(60, 25);
            this.txtPOI1.TabIndex = 37;
            // 
            // txtPOI2
            // 
            this.txtPOI2.Location = new System.Drawing.Point(522, 827);
            this.txtPOI2.Multiline = true;
            this.txtPOI2.Name = "txtPOI2";
            this.txtPOI2.Size = new System.Drawing.Size(60, 25);
            this.txtPOI2.TabIndex = 38;
            // 
            // txtPOI3
            // 
            this.txtPOI3.Location = new System.Drawing.Point(588, 732);
            this.txtPOI3.Multiline = true;
            this.txtPOI3.Name = "txtPOI3";
            this.txtPOI3.Size = new System.Drawing.Size(60, 25);
            this.txtPOI3.TabIndex = 39;
            // 
            // txtPOI4
            // 
            this.txtPOI4.Location = new System.Drawing.Point(588, 763);
            this.txtPOI4.Multiline = true;
            this.txtPOI4.Name = "txtPOI4";
            this.txtPOI4.Size = new System.Drawing.Size(60, 25);
            this.txtPOI4.TabIndex = 40;
            // 
            // txtVinGain
            // 
            this.txtVinGain.Location = new System.Drawing.Point(654, 732);
            this.txtVinGain.Multiline = true;
            this.txtVinGain.Name = "txtVinGain";
            this.txtVinGain.Size = new System.Drawing.Size(60, 25);
            this.txtVinGain.TabIndex = 41;
            // 
            // txtVoutGain
            // 
            this.txtVoutGain.Location = new System.Drawing.Point(654, 765);
            this.txtVoutGain.Multiline = true;
            this.txtVoutGain.Name = "txtVoutGain";
            this.txtVoutGain.Size = new System.Drawing.Size(60, 25);
            this.txtVoutGain.TabIndex = 42;
            // 
            // txtIinGain
            // 
            this.txtIinGain.Location = new System.Drawing.Point(654, 796);
            this.txtIinGain.Multiline = true;
            this.txtIinGain.Name = "txtIinGain";
            this.txtIinGain.Size = new System.Drawing.Size(60, 25);
            this.txtIinGain.TabIndex = 43;
            // 
            // txtIoutGain
            // 
            this.txtIoutGain.Location = new System.Drawing.Point(654, 827);
            this.txtIoutGain.Multiline = true;
            this.txtIoutGain.Name = "txtIoutGain";
            this.txtIoutGain.Size = new System.Drawing.Size(60, 25);
            this.txtIoutGain.TabIndex = 44;
            // 
            // txtIoutOffset
            // 
            this.txtIoutOffset.Location = new System.Drawing.Point(720, 827);
            this.txtIoutOffset.Multiline = true;
            this.txtIoutOffset.Name = "txtIoutOffset";
            this.txtIoutOffset.Size = new System.Drawing.Size(60, 25);
            this.txtIoutOffset.TabIndex = 48;
            // 
            // txtIinOffset
            // 
            this.txtIinOffset.Location = new System.Drawing.Point(720, 796);
            this.txtIinOffset.Multiline = true;
            this.txtIinOffset.Name = "txtIinOffset";
            this.txtIinOffset.Size = new System.Drawing.Size(60, 25);
            this.txtIinOffset.TabIndex = 47;
            // 
            // txtVoutOffset
            // 
            this.txtVoutOffset.Location = new System.Drawing.Point(720, 765);
            this.txtVoutOffset.Multiline = true;
            this.txtVoutOffset.Name = "txtVoutOffset";
            this.txtVoutOffset.Size = new System.Drawing.Size(60, 25);
            this.txtVoutOffset.TabIndex = 46;
            // 
            // txtVinOffset
            // 
            this.txtVinOffset.Location = new System.Drawing.Point(720, 732);
            this.txtVinOffset.Multiline = true;
            this.txtVinOffset.Name = "txtVinOffset";
            this.txtVinOffset.Size = new System.Drawing.Size(60, 25);
            this.txtVinOffset.TabIndex = 45;
            // 
            // txtDroopBound
            // 
            this.txtDroopBound.Location = new System.Drawing.Point(786, 827);
            this.txtDroopBound.Multiline = true;
            this.txtDroopBound.Name = "txtDroopBound";
            this.txtDroopBound.Size = new System.Drawing.Size(60, 25);
            this.txtDroopBound.TabIndex = 52;
            // 
            // txtDroopConst
            // 
            this.txtDroopConst.Location = new System.Drawing.Point(786, 796);
            this.txtDroopConst.Multiline = true;
            this.txtDroopConst.Name = "txtDroopConst";
            this.txtDroopConst.Size = new System.Drawing.Size(60, 25);
            this.txtDroopConst.TabIndex = 51;
            // 
            // txtCANid
            // 
            this.txtCANid.Location = new System.Drawing.Point(786, 765);
            this.txtCANid.Multiline = true;
            this.txtCANid.Name = "txtCANid";
            this.txtCANid.Size = new System.Drawing.Size(60, 25);
            this.txtCANid.TabIndex = 50;
            // 
            // txtLoadSharing
            // 
            this.txtLoadSharing.Location = new System.Drawing.Point(786, 732);
            this.txtLoadSharing.Multiline = true;
            this.txtLoadSharing.Name = "txtLoadSharing";
            this.txtLoadSharing.Size = new System.Drawing.Size(60, 25);
            this.txtLoadSharing.TabIndex = 49;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(852, 827);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(60, 25);
            this.textBox5.TabIndex = 56;
            // 
            // txtLoadSharingDutyAve
            // 
            this.txtLoadSharingDutyAve.Location = new System.Drawing.Point(852, 796);
            this.txtLoadSharingDutyAve.Multiline = true;
            this.txtLoadSharingDutyAve.Name = "txtLoadSharingDutyAve";
            this.txtLoadSharingDutyAve.Size = new System.Drawing.Size(60, 25);
            this.txtLoadSharingDutyAve.TabIndex = 55;
            // 
            // txtLoadSharingPeerAve
            // 
            this.txtLoadSharingPeerAve.Location = new System.Drawing.Point(852, 765);
            this.txtLoadSharingPeerAve.Multiline = true;
            this.txtLoadSharingPeerAve.Name = "txtLoadSharingPeerAve";
            this.txtLoadSharingPeerAve.Size = new System.Drawing.Size(60, 25);
            this.txtLoadSharingPeerAve.TabIndex = 54;
            // 
            // txtSelfIoutCheat
            // 
            this.txtSelfIoutCheat.Location = new System.Drawing.Point(852, 732);
            this.txtSelfIoutCheat.Multiline = true;
            this.txtSelfIoutCheat.Name = "txtSelfIoutCheat";
            this.txtSelfIoutCheat.Size = new System.Drawing.Size(60, 25);
            this.txtSelfIoutCheat.TabIndex = 53;
            // 
            // txtDebugTime
            // 
            this.txtDebugTime.Location = new System.Drawing.Point(984, 827);
            this.txtDebugTime.Multiline = true;
            this.txtDebugTime.Name = "txtDebugTime";
            this.txtDebugTime.Size = new System.Drawing.Size(60, 25);
            this.txtDebugTime.TabIndex = 60;
            // 
            // txtDebugFreq
            // 
            this.txtDebugFreq.Location = new System.Drawing.Point(984, 796);
            this.txtDebugFreq.Multiline = true;
            this.txtDebugFreq.Name = "txtDebugFreq";
            this.txtDebugFreq.Size = new System.Drawing.Size(60, 25);
            this.txtDebugFreq.TabIndex = 59;
            // 
            // txtDebugCntr
            // 
            this.txtDebugCntr.Location = new System.Drawing.Point(984, 765);
            this.txtDebugCntr.Multiline = true;
            this.txtDebugCntr.Name = "txtDebugCntr";
            this.txtDebugCntr.Size = new System.Drawing.Size(60, 25);
            this.txtDebugCntr.TabIndex = 58;
            // 
            // txtDebugPts
            // 
            this.txtDebugPts.Location = new System.Drawing.Point(984, 732);
            this.txtDebugPts.Multiline = true;
            this.txtDebugPts.Name = "txtDebugPts";
            this.txtDebugPts.Size = new System.Drawing.Size(60, 25);
            this.txtDebugPts.TabIndex = 57;
            // 
            // txtOpenLoopDuty
            // 
            this.txtOpenLoopDuty.Location = new System.Drawing.Point(918, 827);
            this.txtOpenLoopDuty.Multiline = true;
            this.txtOpenLoopDuty.Name = "txtOpenLoopDuty";
            this.txtOpenLoopDuty.Size = new System.Drawing.Size(60, 25);
            this.txtOpenLoopDuty.TabIndex = 64;
            // 
            // txtContrlLoop
            // 
            this.txtContrlLoop.Location = new System.Drawing.Point(918, 796);
            this.txtContrlLoop.Multiline = true;
            this.txtContrlLoop.Name = "txtContrlLoop";
            this.txtContrlLoop.Size = new System.Drawing.Size(60, 25);
            this.txtContrlLoop.TabIndex = 63;
            // 
            // txtKi
            // 
            this.txtKi.Location = new System.Drawing.Point(918, 765);
            this.txtKi.Multiline = true;
            this.txtKi.Name = "txtKi";
            this.txtKi.Size = new System.Drawing.Size(60, 25);
            this.txtKi.TabIndex = 62;
            // 
            // txtKp
            // 
            this.txtKp.Location = new System.Drawing.Point(918, 732);
            this.txtKp.Multiline = true;
            this.txtKp.Name = "txtKp";
            this.txtKp.Size = new System.Drawing.Size(60, 25);
            this.txtKp.TabIndex = 61;
            // 
            // txtFWTime
            // 
            this.txtFWTime.Location = new System.Drawing.Point(306, 759);
            this.txtFWTime.Multiline = true;
            this.txtFWTime.Name = "txtFWTime";
            this.txtFWTime.Size = new System.Drawing.Size(80, 25);
            this.txtFWTime.TabIndex = 65;
            // 
            // txtSOAVinMin
            // 
            this.txtSOAVinMin.Location = new System.Drawing.Point(1050, 827);
            this.txtSOAVinMin.Multiline = true;
            this.txtSOAVinMin.Name = "txtSOAVinMin";
            this.txtSOAVinMin.Size = new System.Drawing.Size(60, 25);
            this.txtSOAVinMin.TabIndex = 69;
            // 
            // txtSOAVinMax
            // 
            this.txtSOAVinMax.Location = new System.Drawing.Point(1050, 796);
            this.txtSOAVinMax.Multiline = true;
            this.txtSOAVinMax.Name = "txtSOAVinMax";
            this.txtSOAVinMax.Size = new System.Drawing.Size(60, 25);
            this.txtSOAVinMax.TabIndex = 68;
            // 
            // txtFanDetection
            // 
            this.txtFanDetection.Location = new System.Drawing.Point(1050, 765);
            this.txtFanDetection.Multiline = true;
            this.txtFanDetection.Name = "txtFanDetection";
            this.txtFanDetection.Size = new System.Drawing.Size(60, 25);
            this.txtFanDetection.TabIndex = 67;
            // 
            // txtFanSpeed
            // 
            this.txtFanSpeed.Location = new System.Drawing.Point(1050, 732);
            this.txtFanSpeed.Multiline = true;
            this.txtFanSpeed.Name = "txtFanSpeed";
            this.txtFanSpeed.Size = new System.Drawing.Size(60, 25);
            this.txtFanSpeed.TabIndex = 66;
            // 
            // txtSOAIavg2
            // 
            this.txtSOAIavg2.Location = new System.Drawing.Point(1116, 827);
            this.txtSOAIavg2.Multiline = true;
            this.txtSOAIavg2.Name = "txtSOAIavg2";
            this.txtSOAIavg2.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIavg2.TabIndex = 73;
            // 
            // txtSOAIavg1
            // 
            this.txtSOAIavg1.Location = new System.Drawing.Point(1116, 796);
            this.txtSOAIavg1.Multiline = true;
            this.txtSOAIavg1.Name = "txtSOAIavg1";
            this.txtSOAIavg1.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIavg1.TabIndex = 72;
            // 
            // txtSOAIoutMax
            // 
            this.txtSOAIoutMax.Location = new System.Drawing.Point(1116, 765);
            this.txtSOAIoutMax.Multiline = true;
            this.txtSOAIoutMax.Name = "txtSOAIoutMax";
            this.txtSOAIoutMax.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIoutMax.TabIndex = 71;
            // 
            // txtSOAVoutMax
            // 
            this.txtSOAVoutMax.Location = new System.Drawing.Point(1116, 732);
            this.txtSOAVoutMax.Multiline = true;
            this.txtSOAVoutMax.Name = "txtSOAVoutMax";
            this.txtSOAVoutMax.Size = new System.Drawing.Size(60, 25);
            this.txtSOAVoutMax.TabIndex = 70;
            // 
            // txtSOAIrms3
            // 
            this.txtSOAIrms3.Location = new System.Drawing.Point(1182, 827);
            this.txtSOAIrms3.Multiline = true;
            this.txtSOAIrms3.Name = "txtSOAIrms3";
            this.txtSOAIrms3.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIrms3.TabIndex = 77;
            // 
            // txtSOAIrms2
            // 
            this.txtSOAIrms2.Location = new System.Drawing.Point(1182, 796);
            this.txtSOAIrms2.Multiline = true;
            this.txtSOAIrms2.Name = "txtSOAIrms2";
            this.txtSOAIrms2.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIrms2.TabIndex = 76;
            // 
            // txtSOAIrms1
            // 
            this.txtSOAIrms1.Location = new System.Drawing.Point(1182, 765);
            this.txtSOAIrms1.Multiline = true;
            this.txtSOAIrms1.Name = "txtSOAIrms1";
            this.txtSOAIrms1.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIrms1.TabIndex = 75;
            // 
            // txtSOAIavg3
            // 
            this.txtSOAIavg3.Location = new System.Drawing.Point(1182, 732);
            this.txtSOAIavg3.Multiline = true;
            this.txtSOAIavg3.Name = "txtSOAIavg3";
            this.txtSOAIavg3.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIavg3.TabIndex = 74;
            // 
            // txtSOAtemp3
            // 
            this.txtSOAtemp3.Location = new System.Drawing.Point(1248, 827);
            this.txtSOAtemp3.Multiline = true;
            this.txtSOAtemp3.Name = "txtSOAtemp3";
            this.txtSOAtemp3.Size = new System.Drawing.Size(60, 25);
            this.txtSOAtemp3.TabIndex = 81;
            // 
            // txtSOAtemp2
            // 
            this.txtSOAtemp2.Location = new System.Drawing.Point(1248, 796);
            this.txtSOAtemp2.Multiline = true;
            this.txtSOAtemp2.Name = "txtSOAtemp2";
            this.txtSOAtemp2.Size = new System.Drawing.Size(60, 25);
            this.txtSOAtemp2.TabIndex = 80;
            // 
            // txtSOAtemp1
            // 
            this.txtSOAtemp1.Location = new System.Drawing.Point(1248, 765);
            this.txtSOAtemp1.Multiline = true;
            this.txtSOAtemp1.Name = "txtSOAtemp1";
            this.txtSOAtemp1.Size = new System.Drawing.Size(60, 25);
            this.txtSOAtemp1.TabIndex = 79;
            // 
            // txtSOAIrms4
            // 
            this.txtSOAIrms4.Location = new System.Drawing.Point(1248, 732);
            this.txtSOAIrms4.Multiline = true;
            this.txtSOAIrms4.Name = "txtSOAIrms4";
            this.txtSOAIrms4.Size = new System.Drawing.Size(60, 25);
            this.txtSOAIrms4.TabIndex = 78;
            // 
            // txtHWFOTPstat
            // 
            this.txtHWFOTPstat.Location = new System.Drawing.Point(1314, 829);
            this.txtHWFOTPstat.Multiline = true;
            this.txtHWFOTPstat.Name = "txtHWFOTPstat";
            this.txtHWFOTPstat.Size = new System.Drawing.Size(60, 25);
            this.txtHWFOTPstat.TabIndex = 85;
            // 
            // txtHWFOVPstat
            // 
            this.txtHWFOVPstat.Location = new System.Drawing.Point(1314, 798);
            this.txtHWFOVPstat.Multiline = true;
            this.txtHWFOVPstat.Name = "txtHWFOVPstat";
            this.txtHWFOVPstat.Size = new System.Drawing.Size(60, 25);
            this.txtHWFOVPstat.TabIndex = 84;
            // 
            // txtHWFOCPstat
            // 
            this.txtHWFOCPstat.Location = new System.Drawing.Point(1314, 767);
            this.txtHWFOCPstat.Multiline = true;
            this.txtHWFOCPstat.Name = "txtHWFOCPstat";
            this.txtHWFOCPstat.Size = new System.Drawing.Size(60, 25);
            this.txtHWFOCPstat.TabIndex = 83;
            // 
            // txtSOAtemp4
            // 
            this.txtSOAtemp4.Location = new System.Drawing.Point(1314, 734);
            this.txtSOAtemp4.Multiline = true;
            this.txtSOAtemp4.Name = "txtSOAtemp4";
            this.txtSOAtemp4.Size = new System.Drawing.Size(60, 25);
            this.txtSOAtemp4.TabIndex = 82;
            // 
            // txtHWFOVPenabled
            // 
            this.txtHWFOVPenabled.Location = new System.Drawing.Point(1380, 829);
            this.txtHWFOVPenabled.Multiline = true;
            this.txtHWFOVPenabled.Name = "txtHWFOVPenabled";
            this.txtHWFOVPenabled.Size = new System.Drawing.Size(60, 25);
            this.txtHWFOVPenabled.TabIndex = 89;
            // 
            // txtHWFOCPenabled
            // 
            this.txtHWFOCPenabled.Location = new System.Drawing.Point(1380, 798);
            this.txtHWFOCPenabled.Multiline = true;
            this.txtHWFOCPenabled.Name = "txtHWFOCPenabled";
            this.txtHWFOCPenabled.Size = new System.Drawing.Size(60, 25);
            this.txtHWFOCPenabled.TabIndex = 88;
            // 
            // txtHWFDCFstat
            // 
            this.txtHWFDCFstat.Location = new System.Drawing.Point(1380, 767);
            this.txtHWFDCFstat.Multiline = true;
            this.txtHWFDCFstat.Name = "txtHWFDCFstat";
            this.txtHWFDCFstat.Size = new System.Drawing.Size(60, 25);
            this.txtHWFDCFstat.TabIndex = 87;
            // 
            // txtHWFMFSstat
            // 
            this.txtHWFMFSstat.Location = new System.Drawing.Point(1380, 734);
            this.txtHWFMFSstat.Multiline = true;
            this.txtHWFMFSstat.Name = "txtHWFMFSstat";
            this.txtHWFMFSstat.Size = new System.Drawing.Size(60, 25);
            this.txtHWFMFSstat.TabIndex = 86;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(1446, 829);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(60, 25);
            this.textBox14.TabIndex = 93;
            // 
            // txtHWFDCFenabled
            // 
            this.txtHWFDCFenabled.Location = new System.Drawing.Point(1446, 798);
            this.txtHWFDCFenabled.Multiline = true;
            this.txtHWFDCFenabled.Name = "txtHWFDCFenabled";
            this.txtHWFDCFenabled.Size = new System.Drawing.Size(60, 25);
            this.txtHWFDCFenabled.TabIndex = 92;
            // 
            // txtHWFMFSenabled
            // 
            this.txtHWFMFSenabled.Location = new System.Drawing.Point(1446, 767);
            this.txtHWFMFSenabled.Multiline = true;
            this.txtHWFMFSenabled.Name = "txtHWFMFSenabled";
            this.txtHWFMFSenabled.Size = new System.Drawing.Size(60, 25);
            this.txtHWFMFSenabled.TabIndex = 91;
            // 
            // txtHWFOTPenabled
            // 
            this.txtHWFOTPenabled.Location = new System.Drawing.Point(1446, 734);
            this.txtHWFOTPenabled.Multiline = true;
            this.txtHWFOTPenabled.Name = "txtHWFOTPenabled";
            this.txtHWFOTPenabled.Size = new System.Drawing.Size(60, 25);
            this.txtHWFOTPenabled.TabIndex = 90;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(1512, 829);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(60, 25);
            this.textBox18.TabIndex = 97;
            // 
            // txtEff
            // 
            this.txtEff.Location = new System.Drawing.Point(1512, 798);
            this.txtEff.Multiline = true;
            this.txtEff.Name = "txtEff";
            this.txtEff.Size = new System.Drawing.Size(60, 25);
            this.txtEff.TabIndex = 96;
            // 
            // txtPin
            // 
            this.txtPin.Location = new System.Drawing.Point(1512, 767);
            this.txtPin.Multiline = true;
            this.txtPin.Name = "txtPin";
            this.txtPin.Size = new System.Drawing.Size(60, 25);
            this.txtPin.TabIndex = 95;
            // 
            // txtPout
            // 
            this.txtPout.Location = new System.Drawing.Point(1512, 734);
            this.txtPout.Multiline = true;
            this.txtPout.Name = "txtPout";
            this.txtPout.Size = new System.Drawing.Size(60, 25);
            this.txtPout.TabIndex = 94;
            // 
            // frmVictorNXP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(1600, 860);
            this.ControlBox = false;
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.txtEff);
            this.Controls.Add(this.txtPin);
            this.Controls.Add(this.txtPout);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.txtHWFDCFenabled);
            this.Controls.Add(this.txtHWFMFSenabled);
            this.Controls.Add(this.txtHWFOTPenabled);
            this.Controls.Add(this.txtHWFOVPenabled);
            this.Controls.Add(this.txtHWFOCPenabled);
            this.Controls.Add(this.txtHWFDCFstat);
            this.Controls.Add(this.txtHWFMFSstat);
            this.Controls.Add(this.txtHWFOTPstat);
            this.Controls.Add(this.txtHWFOVPstat);
            this.Controls.Add(this.txtHWFOCPstat);
            this.Controls.Add(this.txtSOAtemp4);
            this.Controls.Add(this.txtSOAtemp3);
            this.Controls.Add(this.txtSOAtemp2);
            this.Controls.Add(this.txtSOAtemp1);
            this.Controls.Add(this.txtSOAIrms4);
            this.Controls.Add(this.txtSOAIrms3);
            this.Controls.Add(this.txtSOAIrms2);
            this.Controls.Add(this.txtSOAIrms1);
            this.Controls.Add(this.txtSOAIavg3);
            this.Controls.Add(this.txtSOAIavg2);
            this.Controls.Add(this.txtSOAIavg1);
            this.Controls.Add(this.txtSOAIoutMax);
            this.Controls.Add(this.txtSOAVoutMax);
            this.Controls.Add(this.txtSOAVinMin);
            this.Controls.Add(this.txtSOAVinMax);
            this.Controls.Add(this.txtFanDetection);
            this.Controls.Add(this.txtFanSpeed);
            this.Controls.Add(this.txtFWTime);
            this.Controls.Add(this.txtOpenLoopDuty);
            this.Controls.Add(this.txtContrlLoop);
            this.Controls.Add(this.txtKi);
            this.Controls.Add(this.txtKp);
            this.Controls.Add(this.txtDebugTime);
            this.Controls.Add(this.txtDebugFreq);
            this.Controls.Add(this.txtDebugCntr);
            this.Controls.Add(this.txtDebugPts);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.txtLoadSharingDutyAve);
            this.Controls.Add(this.txtLoadSharingPeerAve);
            this.Controls.Add(this.txtSelfIoutCheat);
            this.Controls.Add(this.txtDroopBound);
            this.Controls.Add(this.txtDroopConst);
            this.Controls.Add(this.txtCANid);
            this.Controls.Add(this.txtLoadSharing);
            this.Controls.Add(this.txtIoutOffset);
            this.Controls.Add(this.txtIinOffset);
            this.Controls.Add(this.txtVoutOffset);
            this.Controls.Add(this.txtVinOffset);
            this.Controls.Add(this.txtIoutGain);
            this.Controls.Add(this.txtIinGain);
            this.Controls.Add(this.txtVoutGain);
            this.Controls.Add(this.txtVinGain);
            this.Controls.Add(this.txtPOI4);
            this.Controls.Add(this.txtPOI3);
            this.Controls.Add(this.txtPOI2);
            this.Controls.Add(this.txtPOI1);
            this.Controls.Add(this.txtAirOut);
            this.Controls.Add(this.txtAirIn);
            this.Controls.Add(this.txtIout);
            this.Controls.Add(this.txtIin);
            this.Controls.Add(this.txtVorFET);
            this.Controls.Add(this.txtVout);
            this.Controls.Add(this.txtVin);
            this.Controls.Add(this.txtVinB4Fuse);
            this.Controls.Add(this.txtVoutSet);
            this.Controls.Add(this.txtFWDate);
            this.Controls.Add(this.chkEcho);
            this.Controls.Add(this.lblNXPDashBoard);
            this.Controls.Add(this.rtbDebug);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SerialdataGridView);
            this.Controls.Add(this.rtbSplit);
            this.Controls.Add(this.btnSend);
            this.Controls.Add(this.rtbReceived);
            this.Controls.Add(this.txtSend);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtdebug);
            this.Controls.Add(this.linkLabelgithub);
            this.Controls.Add(this.txtSerialPort);
            this.Controls.Add(this.btnCloseFrm);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.comboBoxCommPorts);
            this.Controls.Add(this.btnScan);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmVictorNXP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "victortagayun.github.io by Victor Tagayun";
            this.Load += new System.EventHandler(this.frmVictorNXP_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SerialdataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.ComboBox comboBoxCommPorts;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Button btnCloseFrm;
        private System.Windows.Forms.TextBox txtSerialPort;
        private System.Windows.Forms.LinkLabel linkLabelgithub;
        private System.Windows.Forms.TextBox txtdebug;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TextBox txtSend;
        private System.Windows.Forms.RichTextBox rtbReceived;
        private System.Windows.Forms.Timer timer_ms;
        private System.Windows.Forms.RichTextBox rtbSplit;
        private System.Windows.Forms.DataGridView SerialdataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RichTextBox rtbDebug;
        private System.Windows.Forms.Label lblNXPDashBoard;
        private System.Windows.Forms.CheckBox chkEcho;
        private System.Windows.Forms.Timer timer_timeout;
        private System.Windows.Forms.TextBox txtFWDate;
        private System.Windows.Forms.TextBox txtVoutSet;
        private System.Windows.Forms.TextBox txtVinB4Fuse;
        private System.Windows.Forms.TextBox txtVin;
        private System.Windows.Forms.TextBox txtVout;
        private System.Windows.Forms.TextBox txtVorFET;
        private System.Windows.Forms.TextBox txtIin;
        private System.Windows.Forms.TextBox txtIout;
        private System.Windows.Forms.TextBox txtAirIn;
        private System.Windows.Forms.TextBox txtAirOut;
        private System.Windows.Forms.TextBox txtPOI1;
        private System.Windows.Forms.TextBox txtPOI2;
        private System.Windows.Forms.TextBox txtPOI3;
        private System.Windows.Forms.TextBox txtPOI4;
        private System.Windows.Forms.TextBox txtVinGain;
        private System.Windows.Forms.TextBox txtVoutGain;
        private System.Windows.Forms.TextBox txtIinGain;
        private System.Windows.Forms.TextBox txtIoutGain;
        private System.Windows.Forms.TextBox txtIoutOffset;
        private System.Windows.Forms.TextBox txtIinOffset;
        private System.Windows.Forms.TextBox txtVoutOffset;
        private System.Windows.Forms.TextBox txtVinOffset;
        private System.Windows.Forms.TextBox txtDroopBound;
        private System.Windows.Forms.TextBox txtDroopConst;
        private System.Windows.Forms.TextBox txtCANid;
        private System.Windows.Forms.TextBox txtLoadSharing;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox txtLoadSharingDutyAve;
        private System.Windows.Forms.TextBox txtLoadSharingPeerAve;
        private System.Windows.Forms.TextBox txtSelfIoutCheat;
        private System.Windows.Forms.TextBox txtDebugTime;
        private System.Windows.Forms.TextBox txtDebugFreq;
        private System.Windows.Forms.TextBox txtDebugCntr;
        private System.Windows.Forms.TextBox txtDebugPts;
        private System.Windows.Forms.TextBox txtOpenLoopDuty;
        private System.Windows.Forms.TextBox txtContrlLoop;
        private System.Windows.Forms.TextBox txtKi;
        private System.Windows.Forms.TextBox txtKp;
        private System.Windows.Forms.TextBox txtFWTime;
        private System.Windows.Forms.TextBox txtSOAVinMin;
        private System.Windows.Forms.TextBox txtSOAVinMax;
        private System.Windows.Forms.TextBox txtFanDetection;
        private System.Windows.Forms.TextBox txtFanSpeed;
        private System.Windows.Forms.TextBox txtSOAIavg2;
        private System.Windows.Forms.TextBox txtSOAIavg1;
        private System.Windows.Forms.TextBox txtSOAIoutMax;
        private System.Windows.Forms.TextBox txtSOAVoutMax;
        private System.Windows.Forms.TextBox txtSOAIrms3;
        private System.Windows.Forms.TextBox txtSOAIrms2;
        private System.Windows.Forms.TextBox txtSOAIrms1;
        private System.Windows.Forms.TextBox txtSOAIavg3;
        private System.Windows.Forms.TextBox txtSOAtemp3;
        private System.Windows.Forms.TextBox txtSOAtemp2;
        private System.Windows.Forms.TextBox txtSOAtemp1;
        private System.Windows.Forms.TextBox txtSOAIrms4;
        private System.Windows.Forms.TextBox txtHWFOTPstat;
        private System.Windows.Forms.TextBox txtHWFOVPstat;
        private System.Windows.Forms.TextBox txtHWFOCPstat;
        private System.Windows.Forms.TextBox txtSOAtemp4;
        private System.Windows.Forms.TextBox txtHWFOVPenabled;
        private System.Windows.Forms.TextBox txtHWFOCPenabled;
        private System.Windows.Forms.TextBox txtHWFDCFstat;
        private System.Windows.Forms.TextBox txtHWFMFSstat;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox txtHWFDCFenabled;
        private System.Windows.Forms.TextBox txtHWFMFSenabled;
        private System.Windows.Forms.TextBox txtHWFOTPenabled;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox txtEff;
        private System.Windows.Forms.TextBox txtPin;
        private System.Windows.Forms.TextBox txtPout;
    }
}

