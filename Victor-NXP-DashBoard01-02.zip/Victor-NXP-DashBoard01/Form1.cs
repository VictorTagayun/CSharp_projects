﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Victor_NXP_DashBoard01
{
    public partial class frmVictorNXP : Form
    {
        static SerialPort myserialPort;
        static bool isSerialConnected;
        static bool isThereAlreadyNewSerial;
        string rxString;
        string[] SerialPacket = new string[100];
        int SerialPacketCntr = 0;
        uint mS_cntr, mS_cntr_timeout;
        bool isMsgEnabled;
        bool isDatalogOn;
        bool isJustOpened = true;
        string CmdSent;

        //Console.Write("Test");

        public frmVictorNXP()
        {
            InitializeComponent();
        }

        private void btnScan_Click(object sender, EventArgs e)
        {
            comboBoxCommPorts.Items.Clear();
            foreach (string comm in SerialPort.GetPortNames())
            {
                comboBoxCommPorts.Items.Add(comm);
            }
        }

        private void comboBoxCommPorts_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void frmVictorNXP_Load(object sender, EventArgs e)
        {
            Console.Write("Test");
            myserialPort = new SerialPort();
            myserialPort.DataReceived += new SerialDataReceivedEventHandler(myserialPort_DataReceived);

            SerialdataGridView.Columns[0].HeaderText = "Data Cnt";
            SerialdataGridView.Columns[1].HeaderText = "Data1";
            SerialdataGridView.Columns[2].HeaderText = "Data2";
            SerialdataGridView.Columns[3].HeaderText = "Data3";
            SerialdataGridView.Columns[4].HeaderText = "Data4";
            SerialdataGridView.Columns[5].HeaderText = "Data5";
        }

        private void btnCloseFrm_Click(object sender, EventArgs e)
        {
            if (myserialPort.IsOpen)
                myserialPort.Close();
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("https://victortagayun.github.io");
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if(comboBoxCommPorts.Text == "")
            {
                MessageBox.Show("Please select correct Serial Comm port!", "ERROR");
            }
            else
            {
                if(btnConnect.Text == "Connect") // Connect
                {
                    if (myserialPort.IsOpen) // Connect : error on connection
                    {
                        MessageBox.Show("Serial Comm port already open!", "ERROR");
                    }
                    else
                    {
                        myserialPort.PortName = comboBoxCommPorts.Text;
                        myserialPort.BaudRate = 19200;
                        myserialPort.Parity = Parity.None;
                        myserialPort.DataBits = 8;
                        myserialPort.StopBits = StopBits.One;
                        myserialPort.Handshake =0;

                        try // open port
                        {
                            myserialPort.Open();
                            txtSerialPort.Text = comboBoxCommPorts.Text;
                            btnConnect.Text = "Disconnect";
                            btnSend.Enabled = true;
                            txtSend.Enabled = true;

                            mS_cntr_timeout = 1000;
                        }
                        catch (Exception ex) // handle the exception
                        {
                            MessageBox.Show("Some app is using the PORT! Please Close the connection!", "ERROR");
                        }
                    }
                }
                else // Disconnect
                {
                    txtSerialPort.Text = "";
                    btnConnect.Text = "Connect";
                    myserialPort.Close();
                    btnSend.Enabled = false;
                    txtSend.Enabled = false;
                }

            }
        }

        private void btnDisConnect_Click(object sender, EventArgs e)
        {
            if (myserialPort.IsOpen)
                myserialPort.Close();
            txtSerialPort.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myserialPort.WriteLine(txtSend.Text);
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            if (chkEcho.Checked)
            {
                rtbReceived.Text += txtSend.Text + "\n";
            }
            myserialPort.WriteLine(txtSend.Text);
        }

        private void myserialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            rxString = myserialPort.ReadLine();
            this.Invoke(new EventHandler(DisplayText));
            //MessageBox.Show(data, "Received");
            //SerialPacket[SerialPacketCntr++] += rxString;
        }

        private void txtdebug_TextChanged(object sender, EventArgs e)
        {

        }

        private void DisplayText(object sender, EventArgs e)
        {
            rtbReceived.Text += rxString + "\n";

            SerialPacketCntr++;

            string[] subs = rxString.Split(',',' ','='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

            foreach (var sub in subs)
            {
                //Console.WriteLine($"Substring: {sub}");
                rtbSplit.Text += sub + "*"; // + "\n";
            }

            rtbSplit.Text = rtbSplit.Text + ">>>>> Length = " + subs.Length + ", mS_cntr = " + mS_cntr.ToString() + ", SerialPacketCntr = " + SerialPacketCntr.ToString() + "\n";

            // string[] row = new string[] { "1", "Product 1", "1000" }; // http://csharp.net-informations.com/datagridview/csharp-datagridview-add-column.htm
            // dataGridView1.Rows.Add(row);

            //SerialdataGridView.Rows.Add(subs);

            //richTextBox1.Text += mS_cntr.ToString() + "\n";

            mS_cntr = 0;

            //process_all();
            process_dho();

        }

        private void SerialdataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; col < SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells.Count; col++)
            {
               //string value = SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells[col].Value.ToString();
            }

            //richTextBox1.Text = richTextBox1.Text + "x" + "\n";

            MessageBox.Show("Pressed", "SerialdataGridView_CellContentClick");

        }

        private void SerialdataGridView_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            MessageBox.Show("Pressed", "SerialdataGridView_CellMouseClick");
        }

        private void SerialdataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            // https://stackoverflow.com/questions/6487839/reading-data-from-datagridview-in-c-sharp

            //for (int col = 0; col < SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells.Count; col++)
            //{
            //   string value = SerialdataGridView.Rows[SerialdataGridView.RowCount - 1].Cells[col].Value.ToString();
            //}

            //richTextBox1.Text = richTextBox1.Text + e.RowIndex + "\n";

        }


        private void timer_ms_Tick(object sender, EventArgs e)
        {
            mS_cntr++;
            txtdebug.Text = mS_cntr.ToString();
            //if (mS_cntr > mS_cntr_timeout)
            //{
            //    timer_ms.Enabled = false;
            //}
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer_ms.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer_ms.Enabled = false;
            mS_cntr = 0;
            SerialPacketCntr = 0;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            txtdebug.Text = SerialdataGridView.RowCount.ToString() + ", " + SerialdataGridView.Rows[1].Cells.Count.ToString(); 

            //txtdebug.Text = SerialdataGridView.Rows.Count.ToString();
        }

        private void SerialdataGridView_RowValidated(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSend_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (chkEcho.Checked)
                {
                    rtbReceived.Text += txtSend.Text + "\n";
                }
                timer_ms.Enabled = true;
                myserialPort.WriteLine(txtSend.Text);
            }
        }

        private void rtbReceived_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            rtbReceived.SelectionStart = rtbReceived.Text.Length;
            // scroll it automatically
            rtbReceived.ScrollToCaret();
        }

        private void rtbSplit_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            rtbSplit.SelectionStart = rtbSplit.Text.Length;
            // scroll it automatically
            rtbSplit.ScrollToCaret();
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            txtdebug.Text = SerialPacketCntr.ToString();
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            txtdebug.Text = SerialPacketCntr.ToString();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            // set the current caret position to the end
            rtbDebug.SelectionStart = rtbDebug.Text.Length;
            // scroll it automatically
            rtbDebug.ScrollToCaret();
        }

        private void txtSend_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer_timeout_Tick(object sender, EventArgs e)
        {

        }

        private void my_processes()
        {
            /*
            * When start of connect to UART 2 conditions:
            * 1. w Dlog, set ismsgenbled = true
            * 2. no Dlog, set ismsgenbled = false
            * 
            * note: set timeout until enable the send command button
            * 
            */
            if(CmdSent == "all?" || isDatalogOn == false) // check all status and if datalog is on 
            {

            }
            else if (CmdSent == "msg" || isJustOpened == true) // this app just opened and cannot determine if msg is enabled or not
            {

            }
            else if (CmdSent == "msg" || isJustOpened == true) // this app just opened and cannot determine if msg is enabled or not
            {

            }
            else if (CmdSent == "msg" || isMsgEnabled == true || isJustOpened == false) // disable msg since msg is already enabled
            {

            }
            else if (CmdSent == "msg" || isMsgEnabled == false || isJustOpened == false) // enable msg since msg is already disabled
            {

            }
            else if (CmdSent == "dhs")
            {

            }
            else if (CmdSent == "dho")
            {

            }
            else if (CmdSent == "dhf")
            {

            }
        }

        private void process_all()
        {
            int word_cntr = 0;

            if (SerialPacketCntr == 3) // FW date / time
            {
                string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtFWDate.Text = subs[2] + " " + subs[3] + " " + subs[4];
                txtFWTime.Text = subs[7];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 23) // Vout Setting
            {
                string[] subs = rxString.Split(',', ' ', '=','(',')'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVoutSet.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 43) // Voltage B4 fuse
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVinB4Fuse.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 44) // Voltage Vin
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVin.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 45) // Voltage Vout
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVout.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 46) // Voltage VorFet
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVorFET.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 49) // Iin
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtIin.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 50) // Iout
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtIout.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 53) // AirIn
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtAirIn.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 54) // AirOut
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtAirOut.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 55) // POI1
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtPOI1.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 56) // POI2
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtPOI2.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 57) // POI3
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtPOI3.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 58) // POI4
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtPOI4.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 60) // Vin Gain & Vin Offset
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVinGain.Text = subs[6];
                txtVinOffset.Text = subs[13];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 61) // Vout Gain
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtVoutGain.Text = subs[6];
                txtVoutOffset.Text = subs[13];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 62) // Iin Gain
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtIinGain.Text = subs[6];
                txtIinOffset.Text = subs[13];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 63) // Iout Gain
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtIoutGain.Text = subs[6];
                txtIoutOffset.Text = subs[13];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 67) // Load Sharing
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtLoadSharing.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 68) // CAN ID
            {
                string[] subs = rxString.Split(',', ' ', '=', ':'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtCANid.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 69) // Droop Const
            {
                string[] subs = rxString.Split(',', ' ', '=', ':','('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtDroopConst.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 70) // Droop Bound
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtDroopBound.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 71) // Self Iout Cheat
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSelfIoutCheat.Text = subs[5];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 72) // Load Sharing peers Ave
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtLoadSharingPeerAve.Text = subs[7];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 73) // Load Sharing Duty Ave
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtLoadSharingDutyAve.Text = subs[7];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 75) // Kp
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtKp.Text = subs[6];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 76) // Ki
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtKi.Text = subs[6];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 77) // Control Loop
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtContrlLoop.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 78) // Control Loop Open Duty
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtOpenLoopDuty.Text = subs[6];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 80) // debug Datalog
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtDebugPts.Text = subs[5];
                txtDebugCntr.Text = subs[10];
                txtDebugFreq.Text = subs[16];
                txtDebugTime.Text = subs[23];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 82) // Fan Speed
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '('); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtFanSpeed.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 83) // Fan Detection
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', '!'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtFanDetection.Text = subs[2];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 86) // SOA Vin Max
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'V'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAVinMax.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 87) // SOA Vin Min
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'V'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAVinMin.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 88) // SOA Vout Max
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'V'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAVoutMax.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 89) // SOA Iout Max
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIoutMax.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 90) // SOA Iavg1
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIavg1.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 91) // SOA Iavg2
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIavg2.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 92) // SOA Iavg3
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIavg3.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 93) // SOA Irms1
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIrms1.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 94) // SOA Irms2
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIrms2.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 95) // SOA Irms3
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIrms3.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 96) // SOA Irms4
            {
                string[] subs = rxString.Split(',', ' ', '=', ':', 'A'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAIrms4.Text = subs[4];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 97) // SOA Temp1
            {
                string[] subs = rxString.Split(',', ' ', '=', 'C'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAtemp1.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 98) // SOA Temp2
            {
                string[] subs = rxString.Split(',', ' ', '=', 'C'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAtemp2.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 99) // SOA Temp3
            {
                string[] subs = rxString.Split(',', ' ', '=', 'C'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAtemp3.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 100) // SOA Temp4
            {
                string[] subs = rxString.Split(',', ' ', '=', 'C'); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                txtSOAtemp4.Text = subs[3];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 101) // SOA HW OCP stat/enalbed
            {
                string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                if (subs[5] == "ON")
                    subs[5] = "ENABLED";
                else if (subs[5] == "OFF")
                    subs[5] = "DISABLED";

                txtHWFOCPenabled.Text = subs[5];
                txtHWFOCPstat.Text = subs[8];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 102) // SOA HW OVP stat/enalbed
            {
                string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                if (subs[5] == "ON")
                    subs[5] = "ENABLED";
                else if (subs[5] == "OFF")
                    subs[5] = "DISABLED";

                txtHWFOVPenabled.Text = subs[5];
                txtHWFOVPstat.Text = subs[8];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 103) // SOA HW OTP stat/enalbed
            {
                string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                if (subs[5] == "ON")
                    subs[5] = "ENABLED";
                else if (subs[5] == "OFF")
                    subs[5] = "DISABLED";

                txtHWFOTPenabled.Text = subs[5];
                txtHWFOTPstat.Text = subs[8];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 104) // SOA HW MFS stat/enalbed
            {
                string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                if (subs[5] == "ON")
                    subs[5] = "ENABLED";
                else if (subs[5] == "OFF")
                    subs[5] = "DISABLED";

                txtHWFMFSenabled.Text = subs[5];
                txtHWFMFSstat.Text = subs[8];

                word_cntr = 0;
            }

            if (SerialPacketCntr == 105) // SOA HW Discharge stat/enalbed
            {
                string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

                //foreach (var sub in subs)
                //{
                //    rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                //    word_cntr++;
                //}

                if (subs[5] == "ON")
                    subs[5] = "ENABLED";
                else if (subs[5] == "OFF")
                    subs[5] = "DISABLED";

                txtHWFDCFenabled.Text = subs[5];
                txtHWFDCFstat.Text = subs[8];

                word_cntr = 0;
            }

        }

        private void process_dhf()
        {

        }

        private void process_dho()
        {
            int word_cntr = 0;
            string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

            foreach (var sub in subs)
            {
                rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                word_cntr++;
            }

            txtVinB4Fuse.Text = subs[11];
            txtVin.Text = subs[13];
            txtVout.Text = subs[15];
            txtVorFET.Text = subs[17];
            txtIin.Text = subs[21];
            txtIout.Text = subs[23];
            txtSOAIavg1.Text = subs[27];
            txtSOAIavg2.Text = subs[29];
            txtSOAIavg3.Text = subs[31];
            txtSOAIrms1.Text = subs[35];
            txtSOAIrms2.Text = subs[37];
            txtSOAIrms3.Text = subs[39];
            txtSOAIrms4.Text = subs[41];
            txtPout.Text = subs[45];
            txtPin.Text = subs[46];
            txtEff.Text = subs[47];
            txtAirIn.Text = subs[50];
            txtAirOut.Text = subs[52];
            txtPOI1.Text = subs[54];
            txtPOI2.Text = subs[56];
            txtPOI3.Text = subs[58];
            txtPOI4.Text = subs[60];
            txtHWFOCPstat.Text = subs[66];
            txtHWFOVPstat.Text = subs[69];
            txtHWFOTPstat.Text = subs[72];
            txtHWFMFSstat.Text = subs[75];
            txtHWFDCFstat.Text = subs[78];

        }

        private void process_dhs()
        {
            int word_cntr = 0;
            string[] subs = rxString.Split(',', ' ', '='); // https://docs.microsoft.com/en-us/dotnet/api/system.string.split?view=net-5.0

            foreach (var sub in subs)
            {
                rtbDebug.Text += "Word = " + sub + ", word-cntr = " + word_cntr + "\n";
                word_cntr++;
            }

            txtVin.Text = subs[3];
            txtVout.Text = subs[5];
            txtIin.Text = subs[7];
            txtIout.Text = subs[9];
            txtAirIn.Text = subs[11];
            txtAirOut.Text = subs[13];
            txtPOI1.Text = subs[15];
            txtPOI2.Text = subs[17];
            txtPOI3.Text = subs[19];
            txtPOI4.Text = subs[21];

        }

        private void process_powerup()
        {

        }

        private void process_fault()
        {

        }

        private void process_SOA_set()
        {

        }

        private void process_HW_enable_set()
        {

        }

        private void process_msg()
        {

        }

        private void process_bnd()
        {

        }

        private void process_frt()
        {

        }

        private void process_adc()
        {

        }

    }
}

